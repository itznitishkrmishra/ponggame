from PIL import Image

# Resize and save player image
player_img = Image.open('player.png')
player_img = player_img.resize((64, 64))
player_img.save('player_resized.png')

# Resize and save enemy image
enemy_img = Image.open('enemy.png')
enemy_img = enemy_img.resize((64, 64))
enemy_img.save('enemy_resized.png')

# Resize and save bullet image
bullet_img = Image.open('bullet.jpeg')
bullet_img = bullet_img.resize((8, 24))
bullet_img.save('bullet_resized.png')

# Resize and save background image
background_img = Image.open('background.jpg')
background_img = background_img.resize((800, 600))
background_img.save('background_resized.jpg')
